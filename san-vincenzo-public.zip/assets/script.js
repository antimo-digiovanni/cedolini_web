const siteChrome=document.getElementById('site-chrome');
if(siteChrome){
 let ticking=false;
 const setScrolled=()=>{siteChrome.classList.toggle('is-scrolled',window.scrollY>24);ticking=false;};
 setScrolled();
 window.addEventListener('scroll',()=>{if(!ticking){ticking=true;requestAnimationFrame(setScrolled);}},{passive:true});
}
const menu=document.querySelector('.menu-toggle');
const nav=document.querySelector('#navigation');
function closeMenu(){menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-label','Apri il menu');nav.classList.remove('open');}
closeMenu();
menu.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));menu.setAttribute('aria-label',open?'Chiudi il menu':'Apri il menu');nav.classList.toggle('open',open);});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu();});
document.addEventListener('click',e=>{if(!e.target.closest('.header'))closeMenu();});
window.addEventListener('pageshow',()=>{document.documentElement.classList.remove('transition-arrival','transition-poster-hold');closeMenu();});
const dialog=document.querySelector('#gallery-dialog');let images=[],position=0;
const render=()=>{dialog.querySelector('img').src=images[position];dialog.querySelector('img').alt=dialog.querySelector('h2').textContent;dialog.querySelector('.gallery-count').textContent=`${position+1} / ${images.length}`;dialog.querySelectorAll('.gallery-prev,.gallery-next').forEach(b=>b.hidden=images.length<2);};
document.querySelectorAll('.machine-photo-trigger').forEach(button=>{
 button.removeAttribute('data-bs-toggle');button.removeAttribute('data-bs-target');button.setAttribute('aria-label','Ingrandisci '+button.dataset.imageTitle);
 button.addEventListener('click',()=>{images=Array.from({length:Number(button.dataset.imageCount)},(_,i)=>button.getAttribute('data-image-src-'+i));position=0;dialog.querySelector('h2').textContent=button.dataset.imageTitle;render();dialog.showModal();});
});
dialog.querySelector('.gallery-close').onclick=()=>dialog.close();
dialog.querySelector('.gallery-prev').onclick=()=>{position=(position+images.length-1)%images.length;render();};
dialog.querySelector('.gallery-next').onclick=()=>{position=(position+1)%images.length;render();};
dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close();});
dialog.addEventListener('keydown',e=>{if(e.key==='ArrowRight'){e.preventDefault();dialog.querySelector('.gallery-next').click();}if(e.key==='ArrowLeft'){e.preventDefault();dialog.querySelector('.gallery-prev').click();}});
