import * as THREE from 'three';

    const pestCanvas = document.getElementById('pest-canvas');
    const pestStage = document.getElementById('pest-stage');
    const pestReducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const pestRenderer = new THREE.WebGLRenderer({ canvas: pestCanvas, antialias: true, alpha: true });
    pestRenderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
    pestRenderer.shadowMap.enabled = true;
    pestRenderer.shadowMap.type = THREE.PCFSoftShadowMap;
    pestRenderer.outputColorSpace = THREE.SRGBColorSpace;
    pestRenderer.toneMapping = THREE.ACESFilmicToneMapping;
    pestRenderer.toneMappingExposure = 1.05;

    const pestScene = new THREE.Scene();
    const pestCamera = new THREE.PerspectiveCamera(28, 1, 0.01, 20);
    pestScene.add(new THREE.HemisphereLight(0xfffaf0, 0x183b32, 1.5));
    const pestKeyLight = new THREE.DirectionalLight(0xffffff, 2.3);
    pestKeyLight.position.set(0.6, 1.2, 0.8);
    pestKeyLight.castShadow = true;
    pestKeyLight.shadow.mapSize.set(1024, 1024);
    Object.assign(pestKeyLight.shadow.camera, { left: -0.5, right: 0.5, top: 0.5, bottom: -0.5, near: 0.1, far: 3 });
    pestKeyLight.shadow.radius = 6;
    pestKeyLight.shadow.bias = -0.0004;
    pestScene.add(pestKeyLight);
    const pestRimLight = new THREE.DirectionalLight(0xade2c9, 2.1);
    pestRimLight.position.set(-0.8, 0.5, -0.6);
    pestScene.add(pestRimLight);
    const pestGround = new THREE.Mesh(new THREE.PlaneGeometry(4, 4), new THREE.ShadowMaterial({ opacity: 0.32 }));
    pestGround.rotation.x = -Math.PI / 2;
    pestGround.receiveShadow = true;
    pestScene.add(pestGround);

    const pestMaterial = (name, color, roughness, metalness = 0) => {
      const material = new THREE.MeshStandardMaterial({ color, roughness, metalness });
      material.name = name;
      return material;
    };
    const pestPlastic = pestMaterial('plastica_scura', 0x343a38, 0.5);
    const pestLidMaterial = pestMaterial('coperchio', 0x414945, 0.4);
    const pestLabelMaterial = pestMaterial('etichetta_verde', 0x4d9b76, 0.6);
    const pestWarningMaterial = pestMaterial('etichetta_gialla', 0xe5bb42, 0.5);
    const pestSteel = pestMaterial('acciaio', 0xc4c7c3, 0.28, 0.35);
    const pestBaitMaterial = pestMaterial('esca', 0x6e9b56, 0.85);
    const pestDarkMaterial = pestMaterial('interno', 0x111513, 0.95);
    const pestMesh = (parent, geometry, material, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) => {
      const object = new THREE.Mesh(geometry, material);
      object.position.set(x, y, z);
      object.rotation.set(rx, ry, rz);
      object.castShadow = true;
      object.receiveShadow = true;
      parent.add(object);
      return object;
    };
    const pestRoundedRect = (width, depth, radius) => {
      const shape = new THREE.Shape();
      const halfWidth = width / 2;
      const halfDepth = depth / 2;
      shape.moveTo(-halfWidth + radius, -halfDepth);
      shape.lineTo(halfWidth - radius, -halfDepth);
      shape.quadraticCurveTo(halfWidth, -halfDepth, halfWidth, -halfDepth + radius);
      shape.lineTo(halfWidth, halfDepth - radius);
      shape.quadraticCurveTo(halfWidth, halfDepth, halfWidth - radius, halfDepth);
      shape.lineTo(-halfWidth + radius, halfDepth);
      shape.quadraticCurveTo(-halfWidth, halfDepth, -halfWidth, halfDepth - radius);
      shape.lineTo(-halfWidth, -halfDepth + radius);
      shape.quadraticCurveTo(-halfWidth, -halfDepth, -halfWidth + radius, -halfDepth);
      return shape;
    };
    const pestExtrude = (shape, depth, bevel) => new THREE.ExtrudeGeometry(shape, {
      depth,
      bevelEnabled: true,
      bevelSize: bevel,
      bevelThickness: bevel,
      bevelSegments: 4,
      curveSegments: 16,
    });

    const pestWidth = 0.3;
    const pestDepth = 0.22;
    const pestHeight = 0.075;
    const pestTop = pestHeight + 0.012;
    const pestStation = new THREE.Group();
    pestScene.add(pestStation);
    pestMesh(pestStation, pestExtrude(pestRoundedRect(pestWidth, pestDepth, 0.03), pestHeight, 0.006), pestPlastic, 0, 0.006, 0, -Math.PI / 2);
    pestMesh(pestStation, new THREE.BoxGeometry(pestWidth - 0.03, 0.001, pestDepth - 0.03), pestDarkMaterial, 0, pestTop + 0.0005, 0);
    const pestHoleRadius = 0.028;
    [-1, 1].forEach((side) => {
      pestMesh(pestStation, new THREE.CylinderGeometry(pestHoleRadius + 0.008, pestHoleRadius + 0.008, 0.02, 40, 1, true), pestPlastic, side * 0.095, 0.042, pestDepth / 2 + 0.012, Math.PI / 2);
      pestMesh(pestStation, new THREE.CircleGeometry(pestHoleRadius, 40), pestDarkMaterial, side * 0.095, 0.042, pestDepth / 2 + 0.0075);
      pestMesh(pestStation, new THREE.TorusGeometry(pestHoleRadius + 0.004, 0.005, 16, 48), pestPlastic, side * 0.095, 0.042, pestDepth / 2 + 0.022);
    });
    const pestLock = new THREE.Group();
    pestLock.position.set(0, 0.062, pestDepth / 2 + 0.012);
    pestStation.add(pestLock);
    pestMesh(pestLock, new THREE.CylinderGeometry(0.011, 0.011, 0.012, 32), pestSteel, 0, 0, 0, Math.PI / 2);
    pestMesh(pestLock, new THREE.BoxGeometry(0.003, 0.012, 0.002), pestDarkMaterial, 0, 0, 0.0065);
    pestMesh(pestStation, new THREE.CylinderGeometry(0.007, 0.007, pestWidth * 0.8, 24), pestPlastic, 0, pestTop + 0.012, -pestDepth / 2 - 0.008, 0, 0, Math.PI / 2);
    const pestRodY = pestTop + 0.008;
    pestMesh(pestStation, new THREE.CylinderGeometry(0.003, 0.003, pestWidth - 0.05, 16), pestSteel, 0, pestRodY, 0, 0, 0, Math.PI / 2);
    [-0.09, -0.05, 0.05, 0.09].forEach((x) => pestMesh(pestStation, new THREE.BoxGeometry(0.006, 0.008, 0.006), pestPlastic, x, pestTop + 0.004, 0));
    const pestBlocks = [-0.07, -0.025, 0.025, 0.07].map((x) => {
      const block = pestMesh(pestStation, new THREE.BoxGeometry(0.03, 0.022, 0.03), pestBaitMaterial, x, pestRodY, 0);
      block.scale.setScalar(0.001);
      return block;
    });
    const pestLidPivot = new THREE.Group();
    pestLidPivot.position.set(0, pestTop + 0.012, -pestDepth / 2 - 0.008);
    pestStation.add(pestLidPivot);
    const pestLidZ = pestDepth / 2 + 0.008;
    pestMesh(pestLidPivot, pestExtrude(pestRoundedRect(pestWidth + 0.008, pestDepth + 0.008, 0.034), 0.022, 0.01), pestLidMaterial, 0, 0.01, pestLidZ, -Math.PI / 2);
    for (let index = -2; index <= 2; index += 1) {
      [-1, 1].forEach((side) => pestMesh(pestLidPivot, new THREE.BoxGeometry(0.012, 0.006, 0.035), pestLidMaterial, index * 0.045, 0.045, pestLidZ + side * 0.075));
    }
    pestMesh(pestLidPivot, new THREE.BoxGeometry(0.16, 0.002, 0.09), pestLabelMaterial, 0, 0.0428, pestLidZ);
    pestMesh(pestLidPivot, new THREE.BoxGeometry(0.16, 0.0025, 0.022), pestWarningMaterial, 0, 0.0432, pestLidZ + 0.03);
    const pestRings = [0, 1, 2].map(() => {
      const ring = new THREE.Mesh(new THREE.RingGeometry(0.2, 0.203, 96), new THREE.MeshBasicMaterial({ color: 0xade2c9, transparent: true, opacity: 0, depthWrite: false }));
      ring.rotation.x = -Math.PI / 2;
      ring.position.y = 0.001;
      pestScene.add(ring);
      return ring;
    });

    const pestEase = (value) => 1 - Math.pow(1 - value, 3);
    const pestEaseInOut = (value) => value < 0.5 ? 4 * value * value * value : 1 - Math.pow(-2 * value + 2, 3) / 2;
    const pestBack = (value) => {
      const overshoot = 1.7;
      return 1 + (overshoot + 1) * Math.pow(value - 1, 3) + overshoot * Math.pow(value - 1, 2);
    };
    const pestSegment = (time, start, end) => Math.min(1, Math.max(0, (time - start) / (end - start)));
    const pestPhases = [[0, 1.8], [1.8, 4.4], [4.4, 6.2], [6.2, 9]];
    const pestSteps = [...document.querySelectorAll('#pest-hero-steps li')];
    const pestTags = ['pest-tag-lock', 'pest-tag-bait', 'pest-tag-monitor'].map((id) => document.getElementById(id));
    let pestStart = performance.now();
    let pestDrag = null;
    let pestUserYaw = 0;
    let pestMouseX = 0;
    let pestMouseY = 0;
    let pestSmoothX = 0;
    let pestSmoothY = 0;
    const pestProjected = new THREE.Vector3();

    function pestResize() {
      const width = pestStage.clientWidth;
      const height = pestStage.clientHeight;
      pestRenderer.setSize(width, height, false);
      pestCamera.aspect = width / height;
      pestCamera.userData.distance = pestCamera.aspect < 1 ? 1.25 : 0.95;
      pestCamera.updateProjectionMatrix();
      if (pestReducedMotion) requestAnimationFrame(pestRender);
    }
    function pestPlaceTag(tag, point, offsetX = 0, offsetY = 0) {
      pestProjected.copy(point).project(pestCamera);
      const width = pestStage.clientWidth;
      const height = pestStage.clientHeight;
      const tagWidth = tag.offsetWidth;
      const tagHeight = tag.offsetHeight;
      let x = (pestProjected.x * 0.5 + 0.5) * width + offsetX;
      let y = (-pestProjected.y * 0.5 + 0.5) * height + offsetY;
      if (x + tagWidth > width - 8) x = (pestProjected.x * 0.5 + 0.5) * width - tagWidth - Math.abs(offsetX);
      tag.style.left = `${Math.round(Math.max(8, Math.min(x, width - tagWidth - 8)))}px`;
      tag.style.top = `${Math.round(Math.max(8, Math.min(y, height - tagHeight - 48)))}px`;
    }
    function pestRender(now = performance.now()) {
      const time = pestReducedMotion ? 9.5 : (now - pestStart) / 1000;
      const drop = pestSegment(time, 0, 1.4);
      pestStation.position.y = (1 - pestBack(drop)) * 0.35;
      pestStation.rotation.y = -0.9 + 0.55 * pestEase(pestSegment(time, 0, 1.8)) + pestUserYaw + Math.sin(time * 0.35) * 0.05 * pestSegment(time, 9, 11);
      const open = pestEaseInOut(pestSegment(time, 1.8, 2.7)) - pestEaseInOut(pestSegment(time, 4.4, 5.2));
      pestLidPivot.rotation.x = -1.85 * open;
      pestBlocks.forEach((block, index) => {
        block.scale.setScalar(Math.max(0.001, pestBack(pestSegment(time, 2.8 + index * 0.18, 3.3 + index * 0.18)) * (1 - pestEaseInOut(pestSegment(time, 4.2, 4.6)))));
      });
      pestLock.rotation.z = -Math.PI / 2 * pestEaseInOut(pestSegment(time, 5.4, 6));
      pestRings.forEach((ring, index) => {
        const phase = ((time - 6.2) / 2.4 + index / 3) % 1;
        const visible = pestSegment(time, 6.2, 6.8);
        ring.scale.setScalar(0.8 + phase * 1.2);
        ring.material.opacity = time < 6.2 ? 0 : (1 - phase) * 0.38 * visible;
      });
      pestSmoothX += (pestMouseX - pestSmoothX) * 0.05;
      pestSmoothY += (pestMouseY - pestSmoothY) * 0.05;
      const distance = pestCamera.userData.distance;
      const settled = pestEase(pestSegment(time, 0, 2.2));
      const angle = 0.5 - 0.25 * settled + pestSmoothX * 0.25;
      const elevation = 0.42 + 0.12 * (1 - settled) + pestSmoothY * 0.12;
      const radius = distance * (1.25 - 0.25 * settled);
      pestCamera.position.set(Math.sin(angle) * radius * Math.cos(elevation), Math.sin(elevation) * radius + 0.03, Math.cos(angle) * radius * Math.cos(elevation));
      pestCamera.lookAt(0, 0.07, 0);
      pestPhases.forEach(([start, end], index) => {
        const step = pestSteps[index];
        step.style.setProperty('--progress', pestSegment(time, start, end));
        step.classList.toggle('is-active', time >= start);
      });
      pestStation.updateMatrixWorld();
      pestPlaceTag(pestTags[0], pestLock.getWorldPosition(new THREE.Vector3()), 24, -4);
      pestTags[0].classList.toggle('is-visible', time > 5.6);
      pestPlaceTag(pestTags[1], pestBlocks[3].getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0, 0.06, 0)), 10, -30);
      pestTags[1].classList.toggle('is-visible', time > 3.2 && time < 4.6);
      pestPlaceTag(pestTags[2], new THREE.Vector3(-0.15, 0, 0.2), 10, 8);
      pestTags[2].classList.toggle('is-visible', time > 6.8);
      pestRenderer.render(pestScene, pestCamera);
    }
    function pestAnimate(now) {
      pestRender(now);
      if (!pestReducedMotion) requestAnimationFrame(pestAnimate);
    }

    new ResizeObserver(pestResize).observe(pestStage);
    pestResize();
    document.getElementById('pest-replay').addEventListener('click', () => {
      pestStart = performance.now();
      if (pestReducedMotion) pestRender();
    });
    pestCanvas.addEventListener('pointerdown', (event) => {
      pestDrag = { x: event.clientX, yaw: pestUserYaw };
      pestCanvas.setPointerCapture(event.pointerId);
    });
    pestCanvas.addEventListener('pointermove', (event) => {
      if (!pestDrag) return;
      pestUserYaw = pestDrag.yaw + (event.clientX - pestDrag.x) * 0.008;
      if (pestReducedMotion) pestRender();
    });
    pestCanvas.addEventListener('pointerup', () => { pestDrag = null; });
    pestCanvas.addEventListener('pointercancel', () => { pestDrag = null; });
    window.addEventListener('pointermove', (event) => {
      pestMouseX = event.clientX / innerWidth - 0.5;
      pestMouseY = event.clientY / innerHeight - 0.5;
      if (pestReducedMotion) pestRender();
    });
    requestAnimationFrame(pestAnimate);
