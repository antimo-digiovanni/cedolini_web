(function () {
  var hero = document.querySelector('.cine-hero');
  if (!hero) return;

  var canvas = hero.querySelector('.cine-hero-canvas');
  var eyebrowEl = hero.querySelector('.cine-hero-eyebrow');
  var taglineEl = hero.querySelector('.cine-hero-tagline');
  var ctaEl = hero.querySelector('.cine-hero-cta');
  var mediaEl = hero.querySelector('.cine-hero-media');
  var glowEl = hero.querySelector('.cine-hero-glow');
  if (!canvas || !canvas.getContext || !eyebrowEl || !taglineEl || !ctaEl) return;

  // No GSAP/ScrollTrigger (CDN unavailable) or reduced motion: keep the
  // static final-logo fallback that is already visible via CSS.
  if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') return;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  gsap.registerPlugin(ScrollTrigger);

  var ctx = canvas.getContext('2d', { alpha: true });
  ctx.imageSmoothingEnabled = true;
  if ('imageSmoothingQuality' in ctx) ctx.imageSmoothingQuality = 'high';

  // Per-breakpoint state (re-assigned on every matchMedia (re)run).
  var frameCount, images, natW, natH, srcTpl, renderedFrame, pendingFrame, frameRequested;

  function frameSrc(i) {
    var n = String(i + 1);
    while (n.length < 4) n = '0' + n;
    return srcTpl.replace('{n}', n);
  }

  function frameReady(i) {
    var im = images[i];
    return !!(im && im.complete && im.naturalWidth);
  }

  function nearestLoaded(index) {
    if (frameReady(index)) return images[index];
    for (var offset = 1; offset < frameCount; offset++) {
      var a = index - offset, b = index + offset;
      if (a >= 0 && frameReady(a)) return images[a];
      if (b < frameCount && frameReady(b)) return images[b];
    }
    return null;
  }

  function draw(index) {
    var img = frameReady(index) ? images[index] : nearestLoaded(index);
    if (!img) return;
    renderedFrame = index;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  }

  function applyPendingFrame() {
    frameRequested = false;
    if (pendingFrame === null) return;
    draw(pendingFrame);
  }

  function queueFrame(i) {
    var clamped = Math.max(0, Math.min(frameCount - 1, Math.round(i)));
    pendingFrame = clamped;
    if (!frameRequested) {
      frameRequested = true;
      requestAnimationFrame(applyPendingFrame);
    }
  }

  function loadFrame(i) {
    if (images[i]) return;
    var im = new Image();
    im.decoding = 'async';
    im.onload = function () {
      // Self-heal: if the frame we're trying to show just became available
      // (or a much closer one did), repaint immediately.
      if (pendingFrame !== null && Math.abs(i - pendingFrame) <= 1 && renderedFrame !== pendingFrame) {
        draw(pendingFrame);
      }
    };
    im.src = frameSrc(i);
    images[i] = im;
  }

  var mm = gsap.matchMedia();

  mm.add(
    { isMobile: '(max-width: 980px)', isDesktop: '(min-width: 981px)' },
    function (context) {
      var isMobile = context.conditions.isMobile;
      var scrollDistance = isMobile ? '180%' : '350%';

      frameCount = parseInt(canvas.dataset[isMobile ? 'framesMobile' : 'framesDesktop'], 10);
      srcTpl = canvas.dataset[isMobile ? 'srcMobile' : 'srcDesktop'];
      natW = parseInt(canvas.dataset[isMobile ? 'widthMobile' : 'widthDesktop'], 10);
      natH = parseInt(canvas.dataset[isMobile ? 'heightMobile' : 'heightDesktop'], 10);
      images = new Array(frameCount);
      renderedFrame = -1;
      pendingFrame = null;
      frameRequested = false;

      if (canvas.width !== natW) canvas.width = natW;
      if (canvas.height !== natH) canvas.height = natH;

      var tl = null;
      var cancelled = false;

      var first = new Image();
      first.decoding = 'async';
      if ('fetchPriority' in first) first.fetchPriority = 'high';
      images[0] = first;
      first.onload = function () {
        if (cancelled) return;
        hero.classList.add('is-enhanced');
        draw(0);
        buildTimeline();
        // First frame is visible: stream in the rest of the sequence
        // without blocking anything else on the page.
        for (var i = 1; i < frameCount; i++) loadFrame(i);
      };
      first.src = frameSrc(0);

      function buildTimeline() {
        gsap.set([eyebrowEl, taglineEl, ctaEl], { autoAlpha: 0, x: -34 });

        tl = gsap.timeline({
          defaults: { ease: 'none' },
          scrollTrigger: {
            trigger: hero,
            start: 'top top',
            end: '+=' + scrollDistance,
            scrub: isMobile ? true : 0.6,
            pin: true,
            anticipatePin: 1
          }
        });

        var frameState = { f: 0 };
        tl.to(frameState, {
          f: frameCount - 1,
          duration: 10,
          onUpdate: function () { queueFrame(frameState.f); }
        }, 0);

        tl.addLabel('reveal', 7.2);
        tl.to(eyebrowEl, { autoAlpha: 1, x: 0, duration: 1.2, ease: 'power2.out' }, 'reveal');
        tl.to(taglineEl, { autoAlpha: 1, x: 0, duration: 1.2, ease: 'power2.out' }, 'reveal+=0.5');
        tl.to(ctaEl, { autoAlpha: 1, x: 0, duration: 1.2, ease: 'power2.out' }, 'reveal+=1');

        tl.to(mediaEl, { scale: 0.94, duration: 1, ease: 'power2.inOut' }, 9);
        if (glowEl) tl.to(glowEl, { opacity: 0.15, duration: 1, ease: 'power2.inOut' }, 9);
      }

      return function () {
        cancelled = true;
        if (tl) tl.kill();
        gsap.set([eyebrowEl, taglineEl, ctaEl, mediaEl], { clearProps: 'all' });
        if (glowEl) gsap.set(glowEl, { clearProps: 'all' });
      };
    }
  );
})();
