(function () {
  if (typeof gsap === 'undefined') return;

  function splitWords(el) {
    var text = el.textContent;
    el.textContent = '';
    text.split(' ').forEach(function (word, i, arr) {
      var span = document.createElement('span');
      span.className = 'word';
      span.textContent = word;
      el.appendChild(span);
      if (i < arr.length - 1) el.appendChild(document.createTextNode(' '));
    });
  }
  document.querySelectorAll('.js-split-words').forEach(splitWords);

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduceMotion || typeof ScrollTrigger === 'undefined') return;

  gsap.registerPlugin(ScrollTrigger);
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(function () { ScrollTrigger.refresh(); });
  }

  var mm = gsap.matchMedia();

  mm.add(
    { isMobile: '(max-width: 780px)', isDesktop: '(min-width: 781px)' },
    function (context) {
      var isMobile = context.conditions.isMobile;

      var revealEls = gsap.utils.toArray('.reveal');
      if (revealEls.length) {
        gsap.set(revealEls, { autoAlpha: 0, y: isMobile ? 20 : 38 });
        ScrollTrigger.batch(revealEls, {
          start: 'top 88%',
          once: true,
          onEnter: function (batch) {
            gsap.to(batch, { autoAlpha: 1, y: 0, duration: 0.9, ease: 'power2.out', stagger: 0.09, overwrite: true });
          }
        });
      }

      var clipHeadings = gsap.utils.toArray('.clip > h1, .clip > h2');
      clipHeadings.forEach(function (h) {
        gsap.set(h, { yPercent: 101, autoAlpha: 0 });
        ScrollTrigger.create({
          trigger: h,
          start: 'top 90%',
          once: true,
          onEnter: function () {
            gsap.to(h, { yPercent: 0, autoAlpha: 1, duration: 1.1, ease: 'power3.out' });
          }
        });
      });

      var splitEls = gsap.utils.toArray('.js-split-words');
      splitEls.forEach(function (el) {
        var words = el.querySelectorAll('.word');
        gsap.set(words, { autoAlpha: 0, y: 16 });
        ScrollTrigger.create({
          trigger: el,
          start: 'top 88%',
          once: true,
          onEnter: function () {
            gsap.to(words, { autoAlpha: 1, y: 0, duration: 0.7, ease: 'power2.out', stagger: 0.025 });
          }
        });
      });

      var revealImages = gsap.utils.toArray('.img-reveal img');
      revealImages.forEach(function (img) {
        gsap.set(img, { clipPath: 'inset(0% 0% 0% 100%)' });
        ScrollTrigger.create({
          trigger: img,
          start: 'top 85%',
          once: true,
          onEnter: function () {
            gsap.to(img, { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.3, ease: 'power3.inOut' });
          }
        });
      });

      var parallaxTweens = [];
      if (!isMobile) {
        gsap.utils.toArray('.parallax-img, .intro-editorial-media img, .fleet-cinematic-feature img').forEach(function (img) {
          parallaxTweens.push(gsap.to(img, {
            yPercent: 8,
            ease: 'none',
            scrollTrigger: { trigger: img, start: 'top bottom', end: 'bottom top', scrub: true }
          }));
        });
      }

      var processItems = gsap.utils.toArray('.process-line li');
      if (processItems.length) {
        ScrollTrigger.batch(processItems, {
          start: 'top 88%',
          once: true,
          onEnter: function (batch) { batch.forEach(function (li) { li.classList.add('is-in'); }); }
        });
      }

      gsap.utils.toArray('[data-count-to]').forEach(function (el) {
        var target = parseFloat(el.dataset.countTo);
        var counter = { val: 0 };
        ScrollTrigger.create({
          trigger: el,
          start: 'top 88%',
          once: true,
          onEnter: function () {
            el.textContent = '0';
            gsap.to(counter, {
              val: target,
              duration: 1.6,
              ease: 'power2.out',
              onUpdate: function () { el.textContent = Math.round(counter.val); }
            });
          }
        });
      });

      var hoverCards = gsap.utils.toArray('.fleet-cinematic-feature, .fleet-cinematic-card');
      var hoverCleanups = [];
      hoverCards.forEach(function (card) {
        var img = card.querySelector('img');
        if (!img) return;
        var scaleTo = gsap.quickTo(img, 'scale', { duration: 0.6, ease: 'power2.out' });
        var onEnter = function () { scaleTo(1.045); };
        var onLeave = function () { scaleTo(1); };
        card.addEventListener('mouseenter', onEnter);
        card.addEventListener('mouseleave', onLeave);
        hoverCleanups.push(function () {
          card.removeEventListener('mouseenter', onEnter);
          card.removeEventListener('mouseleave', onLeave);
        });
      });

      return function () {
        parallaxTweens.forEach(function (t) { t.kill(); });
        hoverCleanups.forEach(function (fn) { fn(); });
        gsap.set(revealEls, { clearProps: 'all' });
        gsap.set(clipHeadings, { clearProps: 'all' });
        gsap.set(revealImages, { clearProps: 'all' });
      };
    }
  );
})();
